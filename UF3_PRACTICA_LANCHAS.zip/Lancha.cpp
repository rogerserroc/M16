#include "Lancha.h"

// constructor
Lancha::Lancha(std::string pName, int pVelocidad, int pDistancia, int pNitro) {

	name = pName;
	velocidad = pVelocidad;
	distancia = pDistancia;
	nitro = pNitro;

}

//getters


std::string Lancha::getName() {
	return name;

}

int Lancha::getVelocidad() {
	return velocidad;

}

int Lancha::getDistancia() {
	return distancia;
}

int Lancha::getNitro() {
	return nitro;

}


//setters

void Lancha::setName(std::string pName) {
	name = pName;
}

void Lancha::setVelocidad(int pVelocidad) {
	velocidad = pVelocidad;
}

void Lancha::setDistancia(int pDistancia) {
	distancia = pDistancia;
}

void Lancha::setNitro(int pNitro) {
	nitro = pNitro;
}


// metodos, Aqui ponemos todo lo que sea hacer calculos

void Lancha::noMasNitroso() {
	int noNitro = 0;
	nitro = nitro - 1;
	std::cout << name << " Se te ha acabado el nitro en la partida, no podras usarlo m�s \n";
	if (nitro < 0) {
	nitro = noNitro;
	}
}
void Lancha::printAtributosIniciales() {
	std::cout << "Los atributos iniciales de " << name << " son los siguientes. La distancia es de " << distancia << " metros. Con una velocidad de " << velocidad << " m/s. Aun le queda " << nitro << " nitro \n";
}
void Lancha::printAtributosFinales() {
	std::cout <<  name << " ha acabado la carrera con una distancia " << distancia << " metros\n";
}
void Lancha::hayNitro() {
	velocidad = velocidad * 2;
}
void Lancha::nohayNitro() {
	velocidad = velocidad / 2;

}
void Lancha::calculoVelocidadDistancia(int pDado) {

	velocidad = velocidad + pDado;
	distancia = distancia + velocidad * 100;

	std::cout << name << " has sacado un " << pDado << "\n";
    std::cout << "Su nueva velocidad es ahora de " << velocidad << " m/s \n";
	std::cout << "Su distancia es ahora de " << distancia << " m \n";
	std::cout << "\n";

}

