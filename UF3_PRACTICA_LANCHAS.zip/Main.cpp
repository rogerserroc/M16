#include "Lancha.h"
#include<stdlib.h>  
#include<time.h>  
#include<windows.h> 


void pregutamosNitro(Lancha& lancha) {
	std::cout << lancha.getName() << " Viendo su velocidad quiere usar el nitro? \n";
	std::cout << "1. Ponemos el modo nano \n";
	std::cout << "2. Lo reservamos por si acaso\n";
	std::cout << "\n";
}

void calculoNitro(Lancha& lancha) {
	int opcion;
	std::cin >> opcion;
	

	if (opcion == 1) {

		int dadoNitro;
		dadoNitro = rand() % 2;
		Sleep(1500);
		std::cout << lancha.getName() << " Como has usado el nitro tiraremos un dado random, si sale 0 tu velocidad se reduce a la mitad, si sale 1 se multiplica �2 \n";
		std::cout << "Has sacado un " << dadoNitro << "\n";

		if (dadoNitro == 0) {

			Sleep(1500);
			lancha.nohayNitro();
			std::cout << "mala suerte, su velocidad ha sido reducida a la mitad, ahora es de  " << lancha.getVelocidad() << "\n";
			lancha.noMasNitroso();
		}

		if (dadoNitro == 1) {
			lancha.hayNitro();
			Sleep(1500);
			std::cout << "ATENCION, se ha activado el modo NANO, su velocidad se acaba de duplicar \n";
			lancha.noMasNitroso();
		}
	}
	if(opcion == 2){
		std::cout << "\n";
		std::cout << lancha.getName() << " Como no has usado nitro tu velocidad no varia y se queda como ha dicho el dado, por lo tanto vas a " << lancha.getVelocidad() << "\n";
	}
}


int main() {

	srand(time(NULL));
	int turnosPartida = 5;
	int dado;
	

	Lancha Lancha1("Jugador1", 0, 0, 1);
	Lancha Lancha2("Jugador2", 0, 0, 1);
	Sleep(1000);
	std::cout << "SE�ORAS Y SE�ORES, ya ha llegado por fin la deseada final de la COPA PISTON \n";
	std::cout << "\n";
	Sleep(2500);
	std::cout << "Ante nosotros tenemos a los dos pilotos �mas completos de la temporada \n";
	Sleep(2500);
	std::cout << "Demosle una calurosa bienvenida a " << Lancha1.getName() << " nuesto campeon, nuestro representante nacional y LEYENDA \n";
	Sleep(3500);
	std::cout << "Ahora toca recibir al aspirante al titulo " << Lancha2.getName() << " el piloto de moda \n";
	std::cout << "\n";
	Sleep(3000);
	std::cout << "Ya sabeis las normas pero la repetire. Se avanzara lanzando un dado cada uno en su turno, solo dispondreis de 1 nitro. El dado es lo que marcara vuestra velocidad \n";
	Sleep(3000);
	std::cout << "Por cierto se me habia olvdidado, vuestra velocidad dependr� de lo que saqueis en el dado \n";
	Sleep(3000);
	std::cout << "\n";

	Lancha1.printAtributosIniciales();
	Lancha2.printAtributosIniciales();
	Sleep(3500);
	std::cout << "\n";

	std::cout << "Que empiece la CARRERA \n";
	std::cout << "\n";
	Sleep(1000);
	std::cout << "3 \n";
	Sleep(1000);
	std::cout << "2 \n";
	Sleep(1000);
	std::cout << "1 \n";
	Sleep(1000);
	std::cout << "\n";
	std::cout << "GOOOOOOOOOO \n";
	std::cout << "\n";
	Sleep(3500);

	for (size_t i = 0; i < 5; i++)
	{	
		dado = rand() % 6 + 1;
		turnosPartida = turnosPartida - 1;
		
		Lancha1.calculoVelocidadDistancia(dado);
		if (Lancha1.getNitro() == 1) {
		pregutamosNitro(Lancha1);
		Sleep(1000);
		calculoNitro(Lancha1);
		Sleep(1500);
		}
		
		std::cout << "Le quedan " << turnosPartida << " turnos \n";
		Sleep(1500);
		std::cout << "\n";
		Sleep(1500);
		
		if (turnosPartida == 0) {
			Sleep(1500);
			std::cout << "No le quedan mas turnos, se ha acabado la participaci�n para ti \n";
		}

		dado = rand() % 6 + 1;

		Lancha2.calculoVelocidadDistancia(dado);
		if (Lancha2.getNitro() == 1) {
		pregutamosNitro(Lancha2);
		Sleep(1000);
		calculoNitro(Lancha2);
		Sleep(1500);
		}
	
		std::cout << "Le quedan " << turnosPartida << " turnos \n";
		Sleep(1500);
		std::cout << "\n";
		Sleep(1500);
		
		if (turnosPartida == 0) {
			Sleep(1500);
			std::cout << "No le quedan mas turnos, se ha acabado la participaci�n para ti \n";
		}
	}
	Sleep(2500);
	std::cout << "QUE PEDAZO DE FINAL, la tension se podria cortar con un cuchillo \n";
	Sleep(2500);
	std::cout << "Pero llegados a este punto solo podemos tener un ganador, asi que hagamos cuenta atr�s... \n";
	Sleep(2500);
	std::cout << "\n";
	std::cout << "3 \n";
	Sleep(1000);
	std::cout << "2 \n";
	Sleep(1000);
	std::cout << "1 \n";
	Sleep(1000);
	std::cout << "......\n";
	std::cout << "\n";
	Sleep(3500);

	
	if (Lancha1.getDistancia() > Lancha2.getDistancia()) {
		std::cout << Lancha1.getName() << " ERES EL CAMPE�N DE LA COPA PISTON, ENHORABUENA \n";
	}
	else {
		std::cout << Lancha2.getName() << " ERES EL CAMPE�N DE LA COPA PISTON ENHORABUENA \n";
	}


	Sleep(2000);
	Lancha1.printAtributosFinales();
	Sleep(2000);
	Lancha2.printAtributosFinales();
	Sleep(2000);
	std::cout << "\n";
	std::cout << "Hasta aqui esta edici�n de la COPA PISTON, espero que hayais disfrutado y nos vemos el a�o que viene\n";
	std::cout << "\n";
	std::cout << "GRACIAS POR JUGAR MI JUEGO \n";
}



// Cosas a arreglar:
//que el nitto sea nulo


